#ifndef UTIL_H
#define UTIL_H

#include "Arduino.h"

float rads2rpm(float rads);
float rpm2rads(float rpm);
float rad2deg(float rad);
float deg2rad(float deg);

#endif